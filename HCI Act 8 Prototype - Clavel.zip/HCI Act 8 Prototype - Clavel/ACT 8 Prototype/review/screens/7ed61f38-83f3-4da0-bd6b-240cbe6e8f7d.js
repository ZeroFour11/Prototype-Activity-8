var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1730429251478.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-7ed61f38-83f3-4da0-bd6b-240cbe6e8f7d" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Lights"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/7ed61f38-83f3-4da0-bd6b-240cbe6e8f7d/style-1730429251478.css" />\
      <div class="freeLayout">\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="57.25px" datasizeheight="51.24px" dataX="28.62" dataY="75.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="57.25" height="51.242759704589844" viewBox="28.62499999999976 75.0 57.25 51.242759704589844" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-7ed61" d="M28.62499999999976 100.63791880249276 C28.62499999999976 101.62918122158378 29.01816449954752 102.62044722559395 29.71372208371949 103.34707449532317 L49.67390533815146 125.11954701610463 C50.399951958007414 125.87962875167386 51.186215325770064 126.24275955566 52.06331902135578 126.24275955566 C53.96858348825697 126.24275955566 55.35976756950042 124.75605055036155 55.35976756950042 122.74081690953014 C55.35976756950042 121.6833948068689 54.996747541139094 120.79136653575448 54.361544530672845 120.13090253451469 L47.557022483116256 112.59774694353139 L38.78660246178808 103.84251749661144 L45.833094107363635 104.30525886508865 L82.48770127933219 104.30525886508865 C84.48381263718971 104.30525886508865 85.8749999999998 102.78546822554549 85.8749999999998 100.63791880249276 C85.8749999999998 98.45728774519534 84.48381263718971 96.93750069057137 82.48770127933219 96.93750069057137 L45.833094107363635 96.93750069057137 L38.81684866154045 97.4002384741294 L47.557022483116256 88.64501261212861 L54.361544530672845 81.11211872024586 C54.996747541139094 80.4513500008753 55.35976756950042 79.55932531468007 55.35976756950042 78.50209142027606 C55.35976756950042 76.48670721283885 53.96858348825697 75.0 52.06331902135578 75.0 C51.186215325770064 75.0 50.36967294258861 75.36342476735936 49.58340957482595 76.18936684574683 L29.71372208371949 97.89568506033683 C29.01816449954752 98.62268516166135 28.62499999999976 99.61357474915705 28.62499999999976 100.63791880249276 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-7ed61" fill="#2196F3" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="348.00px" datasizeheight="296.00px" dataX="41.00" dataY="448.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/cb5ca3f4-d4da-4a36-97b2-c3bf552bce82.jfif" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Path_31" class="path firer commentable non-processed" customid="Lightbulb"   datasizewidth="180.92px" datasizeheight="219.81px" dataX="124.54" dataY="194.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="180.92184448242188" height="219.8125" viewBox="124.53908038139326 194.0 180.92184448242188 219.8125" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_31-7ed61" d="M172.738764364214 364.6145911278261 L257.26177475365046 364.6145911278261 C261.829701832071 364.6145911278261 264.91353037997476 362.1083424560053 264.91353037997476 358.39488903744416 L264.91353037997476 344.19275279669455 C264.91353037997476 321.7293611580657 305.4609196186064 307.6191043848329 305.4609196186064 266.59006729276143 C305.4609196186064 223.147386201567 269.02532656420794 194.0 215.00026336217513 194.0 C160.86057254791717 194.0 124.53908038139326 223.147386201567 124.53908038139326 266.59006729276143 C124.53908038139326 307.6191043848329 165.0869839508615 321.7293611580657 165.0869839508615 344.19275279669455 L165.0869839508615 358.39488903744416 C165.0869839508615 362.1083424560053 168.17082489227937 364.6145911278261 172.738764364214 364.6145911278261 Z M184.96107449395515 343.91393154918285 C184.96107449395515 315.6955331844954 144.75585778704877 301.58528648355684 144.75585778704877 266.59006729276143 C144.75585778704877 232.8012923904957 172.85311931912833 210.43020325573917 215.00026336217513 210.43020325573917 C257.14740740522205 210.43020325573917 285.2450655297539 232.8012923904957 285.2450655297539 266.59006729276143 C285.2450655297539 301.58528648355684 244.92509727548088 315.6955331844954 244.92509727548088 343.91393154918285 L244.92509727548088 348.4628011916843 L184.96107449395515 348.4628011916843 L184.96107449395515 343.91393154918285 Z M176.05132760897462 390.4207354699877 L253.94921150888987 390.4207354699877 C260.1168933917256 390.4207354699877 265.1422650768316 386.3355136732148 265.1422650768316 381.2300490542848 C265.1422650768316 376.21753156605484 260.1168933917256 372.0404303017651 253.94921150888987 372.0404303017651 L176.05132760897462 372.0404303017651 C169.88364572613892 372.0404303017651 164.85826164751876 376.21753156605484 164.85826164751876 381.2300490542848 C164.85826164751876 386.3355136732148 169.88364572613892 390.4207354699877 176.05132760897462 390.4207354699877 Z M215.00026336217513 413.81249046325684 C231.67614561542254 413.81249046325684 243.66973344182094 407.5008887607697 244.81072992705242 397.9395016300384 L185.07542944886947 397.9395016300384 C186.21773964659917 407.5008887607697 198.09565880558506 413.81249046325684 215.00026336217513 413.81249046325684 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_31-7ed61" fill="#3AB8F8" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="348.00px" datasizeheight="296.00px" dataX="41.00" dataY="448.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/63becded-a739-4796-8d13-abcedae01f5e.jfif" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_1" class="richtext autofit firer ie-background commentable non-processed" customid="Lights"   datasizewidth="143.98px" datasizeheight="55.00px" dataX="143.01" dataY="98.74" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Lights</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;