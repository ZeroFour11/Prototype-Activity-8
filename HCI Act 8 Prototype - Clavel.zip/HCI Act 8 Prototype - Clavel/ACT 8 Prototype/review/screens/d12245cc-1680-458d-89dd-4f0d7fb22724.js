var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1730429251478.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/d12245cc-1680-458d-89dd-4f0d7fb22724/style-1730429251478.css" />\
      <div class="freeLayout">\
      <div id="s-Slice_1" class="slice firer ie-background commentable non-processed" customid="Slice 1" datasizewidth="430.00px" datasizeheight="931.85px" dataX="-0.00" dataY="-0.00" >\
        <div class="layoutWrapper scrollable">\
        	<div class="paddingLayer">\
        	  <div class="freeLayout">\
        	    <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="430.00px" datasizeheight="768.71px" datasizewidthpx="430.00000000000136" datasizeheightpx="768.706849315069" dataX="-0.00" dataY="81.57" >\
        	      <div class="backgroundLayer">\
        	        <div class="colorLayer"></div>\
        	        <div class="imageLayer"></div>\
        	      </div>\
        	      <div class="borderLayer">\
        	        <div class="paddingLayer">\
        	          <div class="content">\
        	            <div class="valign">\
        	              <span id="rtr-s-Rectangle_1_0"></span>\
        	            </div>\
        	          </div>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
        </div>\
      </div>\
      <div id="s-Input_text_1" class="text firer click commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="65.00" dataY="237.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Appliances"/></div></div>  </div></div></div>\
      <div id="s-Input_text_4" class="text firer click commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="65.00" dataY="538.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Lights"/></div></div>  </div></div></div>\
      <div id="s-Input_text_5" class="text firer click commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="65.00" dataY="443.43" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Reminders"/></div></div>  </div></div></div>\
      <div id="s-Input_text_6" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="65.00" dataY="337.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Appliances"/></div></div>  </div></div></div>\
      <div id="s-Input_text_7" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="65.00" dataY="337.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Appliances"/></div></div>  </div></div></div>\
      <div id="s-Input_text_8" class="text firer click commentable non-processed" customid="Input text 1"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="65.00" dataY="337.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Weather"/></div></div>  </div></div></div>\
      <div id="s-Path_111" class="path firer commentable non-processed" customid="Mic"   datasizewidth="116.43px" datasizeheight="116.33px" dataX="156.79" dataY="646.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="116.42964172363281" height="116.3271255493164" viewBox="156.7851800918581 646.0 116.42964172363281 116.3271255493164" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_111-d1224" d="M215.0001736275235 721.2237590380798 C230.4684760526092 721.2237590380798 241.89762352685273 713.183175531143 241.89762352685273 701.4391841857544 L241.89762352685273 665.7846351226059 C241.89762352685273 654.0408274580723 230.4684760526092 646.0 215.0001736275235 646.0 C199.53187120243783 646.0 188.1027319961716 654.0408274580723 188.1027319961716 665.7846351226059 L188.1027319961716 701.4391841857544 C188.1027319961716 713.183175531143 199.53187120243783 721.2237590380798 215.0001736275235 721.2237590380798 Z M156.7851800918581 702.6561961306454 C156.7851800918581 724.5564013307091 177.73952522747814 739.5270912955855 207.91364067499958 741.5373978930678 L207.91364067499958 752.2762301996886 L179.9492331089123 752.2762301996886 C175.9107561322088 752.2762301996886 172.55804999677957 754.4983897032939 172.55804999677957 757.3019794733142 C172.55804999677957 760.0525887967234 175.9107561322088 762.3271203041077 179.9492331089123 762.3271203041077 L250.05137045343108 762.3271203041077 C254.08968207058854 762.3271203041077 257.4422145784945 760.0525887967234 257.4422145784945 757.3019794733142 C257.4422145784945 754.4983897032939 254.08968207058854 752.2762301996886 250.05137045343108 752.2762301996886 L222.08670658004743 752.2762301996886 L222.08670658004743 741.5373978930678 C252.26125196238854 739.5270912955855 273.2148199081423 724.5564013307091 273.2148199081423 702.6561961306454 L273.2148199081423 692.2345519604573 C273.2148199081423 689.4309679304639 270.01486465334847 687.2623743561946 265.97656957214554 687.2623743561946 C261.9382744909427 687.2623743561946 258.5848655774429 689.4309679304639 258.5848655774429 692.2345519604573 L258.5848655774429 702.2854363248498 C258.5848655774429 720.3245436724536 240.98384667554967 732.1744614709038 215.0001736275235 732.1744614709038 C189.01650884747465 732.1744614709038 171.4151344225575 720.3245436724536 171.4151344225575 702.2854363248498 L171.4151344225575 692.2345519604573 C171.4151344225575 689.4309679304639 168.13863423391126 687.2623743561946 164.1001572572078 687.2623743561946 C160.06168441449296 687.2623743561946 156.7851800918581 689.4309679304639 156.7851800918581 692.2345519604573 L156.7851800918581 702.6561961306454 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_111-d1224" fill="#2196F3" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;