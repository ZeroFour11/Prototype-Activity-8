var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1730429251478.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-61b35872-2aa7-47c2-98af-a1dbe4b43953" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Weather"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/61b35872-2aa7-47c2-98af-a1dbe4b43953/style-1730429251478.css" />\
      <div class="freeLayout">\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="268.00px" datasizeheight="221.00px" dataX="81.00" dataY="273.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/069289f1-6c12-4444-924f-13efd5e89136.jfif" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_text_2" class="text firer commentable non-processed" customid="Input text 2"  datasizewidth="166.00px" datasizeheight="45.00px" dataX="132.00" dataY="273.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="Monday"/></div></div>  </div></div></div>\
      <div id="s-Input_text_1" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="315.50px" datasizeheight="71.95px" dataX="57.25" dataY="170.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="6:30 am"/></div></div>  </div></div></div>\
      <div id="s-Date_1" class="date firer commentable non-processed" customid="Date 1" value="" format="MM/dd/yyyy"  datasizewidth="430.00px" datasizeheight="487.50px" dataX="-0.00" dataY="444.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1" readonly="readonly" /></div></div></div></div></div>\
      <div id="s-Input_text_3" class="text firer commentable non-processed" customid="Input text 3"  datasizewidth="300.00px" datasizeheight="45.00px" dataX="65.00" dataY="443.50" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="10 &deg;C"/></div></div>  </div></div></div>\
      <div id="s-Path_5" class="path firer click commentable non-processed" customid="Arrow left"   datasizewidth="57.25px" datasizeheight="51.24px" dataX="28.62" dataY="75.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="57.25" height="51.242759704589844" viewBox="28.62499999999976 75.0 57.25 51.242759704589844" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-61b35" d="M28.62499999999976 100.63791880249276 C28.62499999999976 101.62918122158378 29.01816449954752 102.62044722559395 29.71372208371949 103.34707449532317 L49.67390533815146 125.11954701610463 C50.399951958007414 125.87962875167386 51.186215325770064 126.24275955566 52.06331902135578 126.24275955566 C53.96858348825697 126.24275955566 55.35976756950042 124.75605055036155 55.35976756950042 122.74081690953014 C55.35976756950042 121.6833948068689 54.996747541139094 120.79136653575448 54.361544530672845 120.13090253451469 L47.557022483116256 112.59774694353139 L38.78660246178808 103.84251749661144 L45.833094107363635 104.30525886508865 L82.48770127933219 104.30525886508865 C84.48381263718971 104.30525886508865 85.8749999999998 102.78546822554549 85.8749999999998 100.63791880249276 C85.8749999999998 98.45728774519534 84.48381263718971 96.93750069057137 82.48770127933219 96.93750069057137 L45.833094107363635 96.93750069057137 L38.81684866154045 97.4002384741294 L47.557022483116256 88.64501261212861 L54.361544530672845 81.11211872024586 C54.996747541139094 80.4513500008753 55.35976756950042 79.55932531468007 55.35976756950042 78.50209142027606 C55.35976756950042 76.48670721283885 53.96858348825697 75.0 52.06331902135578 75.0 C51.186215325770064 75.0 50.36967294258861 75.36342476735936 49.58340957482595 76.18936684574683 L29.71372208371949 97.89568506033683 C29.01816449954752 98.62268516166135 28.62499999999976 99.61357474915705 28.62499999999976 100.63791880249276 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-61b35" fill="#2196F3" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;