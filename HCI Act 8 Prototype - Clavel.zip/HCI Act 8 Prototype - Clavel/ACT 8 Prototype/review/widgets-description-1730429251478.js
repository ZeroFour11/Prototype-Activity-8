	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_1", "02a452d1-4a97-4c32-a99a-afb049cd606b"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "02a452d1-4a97-4c32-a99a-afb049cd606b"]] = ["Arrow left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_1", "7ed61f38-83f3-4da0-bd6b-240cbe6e8f7d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "7ed61f38-83f3-4da0-bd6b-240cbe6e8f7d"]] = ["Arrow left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_31", "7ed61f38-83f3-4da0-bd6b-240cbe6e8f7d"]] = ""; 

			widgets.rootWidgetMap[["s-Path_31", "7ed61f38-83f3-4da0-bd6b-240cbe6e8f7d"]] = ["Light bulb", "s-Path_31"]; 

	widgets.descriptionMap[["s-Path_1", "81d254f9-2412-4e52-a9d3-dea59b02a691"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "81d254f9-2412-4e52-a9d3-dea59b02a691"]] = ["Arrow left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_30", "81d254f9-2412-4e52-a9d3-dea59b02a691"]] = ""; 

			widgets.rootWidgetMap[["s-Path_30", "81d254f9-2412-4e52-a9d3-dea59b02a691"]] = ["Light bulb slash", "s-Path_30"]; 

	widgets.descriptionMap[["s-Path_1", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ["Arrow left", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ["Arrow left", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_91", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ""; 

			widgets.rootWidgetMap[["s-Path_91", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ["Bell", "s-Path_91"]; 

	widgets.descriptionMap[["s-Path_3", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ["Bell", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_4", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ""; 

			widgets.rootWidgetMap[["s-Path_4", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ["Bell", "s-Path_4"]; 

	widgets.descriptionMap[["s-Path_60", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ""; 

			widgets.rootWidgetMap[["s-Path_60", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ["Pencil", "s-Path_60"]; 

	widgets.descriptionMap[["s-Path_5", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ["Pencil", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ["Pencil", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_29", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ""; 

			widgets.rootWidgetMap[["s-Path_29", "202dfd9b-f1eb-416e-bf11-dddfe31aa571"]] = ["Plus", "s-Path_29"]; 

	widgets.descriptionMap[["s-Path_111", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_111", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Mic", "s-Path_111"]; 

	widgets.descriptionMap[["s-Path_5", "61b35872-2aa7-47c2-98af-a1dbe4b43953"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "61b35872-2aa7-47c2-98af-a1dbe4b43953"]] = ["Arrow left", "s-Path_5"]; 

	