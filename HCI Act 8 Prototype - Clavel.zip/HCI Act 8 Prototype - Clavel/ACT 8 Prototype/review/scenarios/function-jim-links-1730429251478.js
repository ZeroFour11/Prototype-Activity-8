(function(window, undefined) {

  var jimLinks = {
    "02a452d1-4a97-4c32-a99a-afb049cd606b" : {
      "Path_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "7ed61f38-83f3-4da0-bd6b-240cbe6e8f7d" : {
      "Path_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_2" : [
        "81d254f9-2412-4e52-a9d3-dea59b02a691"
      ]
    },
    "81d254f9-2412-4e52-a9d3-dea59b02a691" : {
      "Path_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_2" : [
        "7ed61f38-83f3-4da0-bd6b-240cbe6e8f7d"
      ]
    },
    "202dfd9b-f1eb-416e-bf11-dddfe31aa571" : {
      "Path_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Input_text_1" : [
        "02a452d1-4a97-4c32-a99a-afb049cd606b"
      ],
      "Input_text_4" : [
        "7ed61f38-83f3-4da0-bd6b-240cbe6e8f7d"
      ],
      "Input_text_5" : [
        "202dfd9b-f1eb-416e-bf11-dddfe31aa571"
      ],
      "Input_text_8" : [
        "61b35872-2aa7-47c2-98af-a1dbe4b43953"
      ]
    },
    "61b35872-2aa7-47c2-98af-a1dbe4b43953" : {
      "Path_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);